# Luary Shop — ERP de Precificação para Semijoias

ERP comercial focado em precificação de semijoias: produtos, kits, insumos, banhos (custo do ouro/prata por grama), marketplaces (canais de venda com todas as taxas), fornecedores, estoque, financeiro/DRE e um gerador de conteúdo para anúncios.

## O que foi corrigido nesta versão

Este projeto veio de um único arquivo `.tsx` pensado para rodar num ambiente de preview (com a chave do Firebase exposta no código). Antes de publicar no GitHub, os seguintes pontos foram corrigidos:

- **Credenciais do Firebase removidas do código-fonte.** Agora vêm de variáveis de ambiente (`.env`, que fica fora do Git). Veja `.env.example`.
- **Regras de segurança do Realtime Database e Storage** (`database.rules.json`, `storage.rules`) para exigir autenticação antes de ler/escrever dados.
- **Exclusão de itens agora pede confirmação** (produtos, kits, insumos, banhos, canais, fornecedores, lançamentos financeiros) — antes apagava direto no clique.
- **Exportação real de Excel e PDF** no Dashboard — antes era só um alerta fingindo gerar o arquivo.
- **Validação de SKU duplicado** ao cadastrar produtos e kits.
- **Tela de carregamento e tela de erro de conexão** — antes, se o Firebase falhasse ao conectar, a tela ficava em branco sem explicação.
- **Projeto transformado em app Vite completo** (antes era um arquivo solto, sem `package.json`, sem build, sem como rodar localmente ou fazer deploy).

### Pontos que continuam simplificados (por escolha, não é bug)
- O **Gerador de SEO** é baseado em templates/regras, não chama nenhuma IA externa — é instantâneo e não depende de nenhuma chave de API extra. Se quiser IA de verdade, dá pra plugar a API da Anthropic ou OpenAI depois (isso exigiria uma função de backend para não expor a chave no navegador).
- O **Financeiro/DRE** soma o que for lançado manualmente; não puxa vendas automaticamente dos marketplaces.
- A autenticação é **anônima** (qualquer pessoa que abrir o link vira "usuário" com acesso total aos dados). Isso é aceitável para uso pessoal/interno, mas veja a seção de segurança abaixo se for usar com equipe ou dados sensíveis.

## Atualização — cadastro e SEO universais (qualquer categoria, não só joias)

- **Cadastro de produto ficou genérico**: além dos campos de joia (peso/banho, que continuam existindo e agora são opcionais), tem Marca, Cor, Medidas e uma lista dinâmica de **Atributos Personalizados** (chave/valor) — funciona pra roupa, eletrônico, casa, qualquer nicho.
- **Gerador de conteúdo virou motor de regras por marketplace** (`src/data/marketplaces.js` + `src/utils/contentGenerator.js`): usa só o que o produto realmente tem preenchido, respeita o limite de caracteres real de cada canal (Mercado Livre, Shopee, Amazon, TikTok Shop) e a estrutura/tom que cada um exige.
- **Precificação**: adicionado o "Preço de Equilíbrio" (0% de margem) no comparativo entre canais, mostrando o piso absoluto de cada marketplace.
- **Removida a configuração órfã do Firestore** (`firestore.rules`) — o projeto sempre usou Realtime Database de fato; a documentação e as regras agora refletem isso corretamente.

## Pré-requisitos

- [Node.js](https://nodejs.org/) 18 ou superior
- Uma conta no [Firebase](https://console.firebase.google.com/) (gratuita)

## 1. Configurar o Firebase

1. Crie um projeto em [console.firebase.google.com](https://console.firebase.google.com/).
2. Em **Build > Authentication > Sign-in method**, ative o provedor **Anônimo**.
3. Em **Build > Realtime Database**, crie o banco (modo produção, mesma região que preferir).
4. Em **Build > Storage**, ative o Storage (para as fotos dos produtos).
5. Em **Configurações do projeto > Seus apps**, crie um app da Web e copie as credenciais (`apiKey`, `authDomain`, `databaseURL` etc.).
6. Publique as regras de segurança inclusas neste repositório:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init database storage   # aponte para o projeto que você criou
   firebase deploy --only database,storage
   ```
   (ou cole o conteúdo de `database.rules.json` e `storage.rules` direto no console do Firebase, nas abas "Regras")

## 2. Rodar localmente

```bash
npm install
cp .env.example .env
# edite o .env e preencha com as credenciais do seu Firebase
npm run dev
```

Abra o endereço mostrado no terminal (geralmente `http://localhost:5173`).

## 3. Build de produção

```bash
npm run build
npm run preview   # para testar o build localmente
```

Os arquivos finais ficam em `dist/`.

## 4. Publicar no GitHub

```bash
git init
git add .
git commit -m "Luary Shop ERP"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/luary-shop.git
git push -u origin main
```

O arquivo `.env` **não vai** para o repositório (está no `.gitignore`) — suas credenciais do Firebase ficam seguras.

## 5. Deploy (hospedagem)

Qualquer host de site estático funciona. Opções simples:

**Vercel / Netlify** (recomendado): conecte o repositório do GitHub, configure as variáveis de ambiente do `.env.example` no painel do serviço, e o deploy é automático a cada `git push`.

**Firebase Hosting**:
```bash
firebase init hosting   # aponte a pasta pública para "dist"
npm run build
firebase deploy --only hosting
```

**GitHub Pages** (workflow já incluso neste projeto em `.github/workflows/deploy.yml`):
1. Suba este projeto para o repositório `luary-shop`.
2. Em **Settings > Secrets and variables > Actions**, cadastre um secret para cada variável do `.env.example` (`VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_DATABASE_URL`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_STORAGE_BUCKET`, `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_APP_ID`), com os valores reais do seu Firebase.
3. Em **Settings > Pages**, em "Source", selecione **GitHub Actions**.
4. Qualquer `git push` na branch `main` dispara o build e publica automaticamente em `https://SEU-USUARIO.github.io/luary-shop/`.
5. Se o nome do seu repositório for diferente de `luary-shop`, ajuste o `base` em `vite.config.js` para bater com o nome real.

> Em qualquer um desses serviços, lembre-se de configurar as variáveis `VITE_FIREBASE_*` do `.env.example` como variáveis de ambiente do próprio serviço de hospedagem — o Vite as injeta no build.

## Segurança — leia antes de usar com dados reais

- As regras atuais (`database.rules.json`) liberam leitura pública e escrita para **qualquer usuário autenticado**, e a autenticação é anônima — ou seja, qualquer pessoa com o link do site vira "usuário" e ganha acesso de escrita aos seus dados. Isso é intencional para simplicidade de uso pessoal.
- Se você for usar com funcionários ou dados sensíveis, troque para autenticação por e-mail/senha e restrinja as regras de escrita a uma lista de UIDs autorizados dentro de `database.rules.json` (troque `"auth != null"` por uma checagem de UID específico).
- A `apiKey` do Firebase que vai no `.env` **não é secreta por natureza** (ela é enviada ao navegador de qualquer forma) — quem protege seus dados são as **regras de segurança**, não a chave em si. Ainda assim, mantenha-a fora do Git por boas práticas e para evitar que outras pessoas usem sua cota do projeto.

## Estrutura do projeto

```
src/
  App.jsx        # aplicação principal (todos os módulos do ERP)
  data/
    marketplaces.js     # regras reais de cada marketplace (limite de caracteres, tom, estrutura)
  utils/
    contentGenerator.js # gerador universal de título/descrição/tags por marketplace
  firebase.js     # inicialização do Firebase a partir das variáveis de ambiente
  main.jsx        # entrypoint do React
  index.css       # Tailwind
database.rules.json  # regras de segurança do Realtime Database
storage.rules     # regras de segurança do storage (fotos)
.env.example      # modelo de variáveis de ambiente
```
